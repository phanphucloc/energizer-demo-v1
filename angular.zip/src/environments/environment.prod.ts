export const environment = {
  production: true,
  baseURlFake : 'http://localhost:4200:/',
  baseURl : 'https://energizer-project-1809.herokuapp.com/api/'
};
