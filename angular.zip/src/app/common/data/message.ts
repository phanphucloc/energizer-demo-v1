export const MESSAGE = {
    NOTIFICATION: 'Thông báo',
    LOGIN_SUCCESS: 'Đăng nhập thành công',
    ADD_SUCCESS: 'Thêm thành công',
    EDIT_SUCCESS: 'Cập nhật thành công',
    ERROR : 'Đã có lỗi xãy ra',
    ENERGY_INCORRECT: 'Vui lòng nhập ít nhất một năng lượng tiêu thụ cho sản xuất',
    PRODUCT_INCORRECT: 'Vui lòng nhập ít nhất một sản phẩm cho lĩnh vực: ',
    BRANCHES_NO_SELECT: 'Không có lĩnh vực nào được chọn'
};
