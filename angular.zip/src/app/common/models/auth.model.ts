
export class UserLogin {
  email: string;
  password: string;
}
export class UserModel {
  uid: string;
  name: string;
  email: string;
  accessToken: string;
  type: string;
}
