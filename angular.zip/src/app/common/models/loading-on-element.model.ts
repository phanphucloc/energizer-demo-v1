export class StyleElement {
  key: string;
  value: string;
}
