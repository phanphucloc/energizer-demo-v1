import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-indicator-report-page',
  templateUrl: './indicator-report-page.component.html',
  styleUrls: ['./indicator-report-page.component.scss']
})
export class IndicatorReportPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
